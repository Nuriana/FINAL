<?php 
defined('BASEPATH') OR exit ('nothing');
/**
* 
*/
class About extends CI_Controller
{
	
	function index()
	{
	$this->load->view('about');	
	}
}
